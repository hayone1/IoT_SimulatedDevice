﻿// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

//This is the code that sends messages to the IoT Hub for testing the routing as defined
//  in this article: https://docs.microsoft.com/en-us/azure/iot-hub/tutorial-routing
//The scripts for creating the resources are included in the resources folder in this
//  Visual Studio solution. 
//
// This program encodes the message body so it can be queried against by the Iot hub.
//
// If you want to read an encoded message body, you can do this:
//   * route the message to storage,
//   * retrieve the message from the storage account by downloading the blob,
//   * use the ReadOneRowFromFile method at the bottom of this module to read the first row of the file.
//   * It will read the file, decode the first row in the file, and write it out to a new file 
//       in ASCII so you can view it.

using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Linq;

namespace SimulatedDevice
{
    public class TelemetryDataPoint
    {
        public string PartitionKey { get; set; }    //type of device
        public string RowKey { get; set; }  //serial number given to device from I2C etc.
        public string deviceId { get; set; }    //name of device
        //the label of the properties eg temperature, humidity
        public string propertyLabel1 { get; set; }  //usually affirms connection
        public string propertyLabel2 { get; set; }  //most important parameter here
        public double property1 { get; set; }   //corresponds to PartitionKey
        public double property2 { get; set; }   //corresponds to RowKey
        public string Etag { get; set; }
        public string Misc { get; set; }    //for any redundant data needed

        public TelemetryDataPoint(string s_partitionKey, string s_rowKey, string s_myDeviceId, string label1, string label2,double s_property1, double s_property2, string s_misc = null)
        {
            PartitionKey = s_partitionKey;
            RowKey = s_rowKey;
            deviceId = s_myDeviceId;
            propertyLabel1 = label1;
            propertyLabel2 = label2;
            property1 = s_property1;
            property2 = s_property2;
            Etag = this.RowKey + this.PartitionKey; //let thus be the E_tag
            Misc = s_misc;
        }
    }
    class Program
    {
        private static DeviceClient s_deviceClient;
        // private static string s_partitionKey = "FourthPartition";
        // private static string s_rowKey = "FourthRow";
        private readonly static string s_myDeviceId = "MyDotnetDevice";
        private readonly static string s_iotHubUri = "FinalYearHub.azure-devices.net";
        // This is the primary key for the device. This is in the portal. 
        // Find your IoT hub in the portal > IoT devices > select your device > copy the key. 
        private readonly static string s_deviceKey = "c/HyNUWA04EyjH5wdfpOuY4PtlCG+gI3BMuqARb7kww=";    //primary key

        // If this is false, it will submit messages to the iot hub. 
        // If this is true, it will read one of the output files and convert it to ASCII.
        private static bool readTheFile = false;

        private static TelemetryDataPoint raspBerryPi = new TelemetryDataPoint("microcontroller", "rpi123", "myrpi", "activated", "connected", 0, 0);
        private static TelemetryDataPoint arduino1 = new TelemetryDataPoint("microcontroller", "ard123", "myard", "connectedassource", "connectedassink", 0, 0);
        private static TelemetryDataPoint arduino2 = new TelemetryDataPoint("microcontroller", "ard124", "myard", "connectedassource", "connectedassink", 0, 0);
        private static TelemetryDataPoint temperatueSensor = new TelemetryDataPoint("temperaturesensor", "tempsens123", "mytemperaturesensor", "connected", "currenttemperture", 0, 0);
        private static TelemetryDataPoint humiditySensor = new TelemetryDataPoint("humiditysensor", "humidsens123", "myhumiditysensor", "connected", "currenthumidity", 0, 0);
        private static TelemetryDataPoint doorSensor = new TelemetryDataPoint("doorsensor", "doorsens123", "mydoorsensor", "connected", "currentdoorstate", 0, 0);
        private static TelemetryDataPoint motionSensor = new TelemetryDataPoint("motionsensor", "humidsens123", "myhumiditysensor", "connected", "active", 0, 0);
        private static TelemetryDataPoint light1 = new TelemetryDataPoint("lightsensor", "lightsens123", "mylightsensor", "connected", "active", 0, 0);
        private static TelemetryDataPoint light2 = new TelemetryDataPoint("lightsensor", "lightsens124", "mylightsensor", "connected", "active", 0, 0);
        //add the devices to list
        private static List<TelemetryDataPoint> telemetryDevices = new List<TelemetryDataPoint>
                {raspBerryPi, arduino1, arduino2, temperatueSensor, humiditySensor, doorSensor, motionSensor, light1, light2};




        private static async Task Main()
        {
            // if (readTheFile)
            // {
            //     // If you want to decode an output file, put the path in ReadOneRowFromFile(), 
            //     //   uncomment the call here and the return command, then run this application.
            //     ReadOneRowFromFile();
            // }
            // else
            // {
                // Send messages to the simulated device. Each message will contain a randomly generated 
                //   Temperature and Humidity.
                // The "level" of each message is set randomly to "storage", "critical", or "normal".
                // The messages are routed to different endpoints depending on the level, temperature, and humidity.
                //  This is set in the tutorial that goes with this sample: 
                //  http://docs.microsoft.com/azure/iot-hub/tutorial-routing

                Console.WriteLine("Routing Tutorial: Simulated device\n");
                // s_deviceClient = DeviceClient.Create(s_iotHubUri,
                // new DeviceAuthenticationWithRegistrySymmetricKey(s_myDeviceId, s_deviceKey), TransportType.Mqtt);
                s_deviceClient = DeviceClient.CreateFromConnectionString("HostName=FinalYearHub.azure-devices.net;DeviceId=RaspberryPi;SharedAccessKey=rwforzwg0XC7eZpARG0bKD+mjoBkX6ebvEOQ26w2RIA=");
                // s_deviceClient = DeviceClient.CreateFromConnectionString("HostName=FinalYearHub.azure-devices.net;DeviceId=MyDotnetDevice;SharedAccessKey=c/HyNUWA04EyjH5wdfpOuY4PtlCG+gI3BMuqARb7kww=");
                // s_deviceClient = DeviceClient.CreateFromConnectionString("HostName=FinalYearHub.azure-devices.net;DeviceId=TestDevice;SharedAccessKey=HpB2T173C3WkFptslBVpJ5vk02d9Lgml8DR/uGTzKks=");


                using var cts = new CancellationTokenSource();
                Console.CancelKeyPress += (sender, eventArgs) =>
                {
                    eventArgs.Cancel = true;
                    cts.Cancel();
                    Console.WriteLine("Exiting...");
                };
                await SendDeviceToCloudMessagesAsync(cts.Token);
                await s_deviceClient.CloseAsync();

                s_deviceClient.Dispose();
                
                //await messages;

            // }
        }

        /// <summary> 
        /// Send message to the Iot hub. This generates the object to be sent to the hub in the message.
        /// </summary>
        private static async Task SendDeviceToCloudMessagesAsync(CancellationToken input_token)
        {

            while (!input_token.IsCancellationRequested)
            {

                string infoString;
                string levelValue;

                // if (rand.NextDouble() > 0.7)
                // {
                //     if (rand.NextDouble() > 0.5)
                //     {
                //         levelValue = "High";
                //         infoString = "This is a critical message.";
                //     }
                //     else
                //     {
                //         levelValue = "storage";
                //         infoString = "This is a storage message.";
                //     }
                // }
                // else
                // {
                //     levelValue = "normal";
                //     infoString = "This is a normal message.";
                // }

                //perfrom actions here

                foreach(TelemetryDataPoint telemetryData in telemetryDevices){
                
                    // serialize the telemetry data and convert it to JSON.
                    var telemetryDataString = JsonConvert.SerializeObject(telemetryData);

                    // Encode the serialized object using UTF-8 so it can be parsed by IoT Hub when
                    using var message = new Message(Encoding.UTF8.GetBytes(telemetryDataString))
                    {
                        
                        ContentEncoding = "utf-8",
                        ContentType = "application/json",
                    };
                    // processing messaging rules.
                // Add one property to the message.
                    levelValue = "normal";
                    infoString = "this is a normal message";
                    message.Properties.Add("level", levelValue);

                    // Submit the message to the hub.
                    try {
                    var t_cts = new CancellationTokenSource(millisecondsDelay: 100000);   //time canellation token of 10 secs
                    await s_deviceClient.SendEventAsync(message, t_cts.Token);   //reference the task
                Console.WriteLine("cancellation isnt requested");
                    // await _telemetryTask;
                    }
                    catch (TaskCanceledException){
                        var timedOutDevice = JsonConvert.DeserializeObject<TelemetryDataPoint>(telemetryDataString);

                        Console.WriteLine("\nTasks cancelled: timed out. while sending telemetry from \n" + timedOutDevice.deviceId);
                        levelValue = "failure";
                        message.Properties.Add("level", levelValue);
                        await s_deviceClient.SendEventAsync(message);    //send but dont await

                    }
                    // tasks.Add(task); 
                Console.WriteLine("{0} > Sent message: parameter {1} : {2} ; {3} \n ", 
                            DateTime.UtcNow,telemetryData.propertyLabel2, telemetryData.property2, infoString);
                }
                // Print out the message.

            await Task.Delay(2000); //delay before sending next telemetry batch

            // await Task.WhenAll(tasks);  //wait for all telemtry to complete
        }
        }


        /// <summary>
        /// This method was written to enable you to decode one of the messages sent to the hub
        ///   and view the body of the message.
        /// Route the messages to storage (they get written to blob storage). 
        /// Send messages to the hub, by running this program with readthefile set to false.
        /// After some messages have been written to storage, download one of the files 
        /// to somewhere you can find it, put the path in this method, and run the program 
        /// with readthefile set to true. 
        /// This method will read in the output file, then convert the first line to a message body object
        /// and write it back out to a new file that you can open and view.
        /// </summary>
        private static void ReadOneRowFromFile()
        {
            string filePathAndName = "C:\\Users\\username\\Desktop\\testfiles\\47_utf32.txt";

            // Set the output file name. 
            // Read in the file to an array of objects. These were encoded in Base64 when they were
            //   written.
            string outputFilePathAndName = filePathAndName.Replace(".txt", "_new.txt");
            string[] fileLines = System.IO.File.ReadAllLines(filePathAndName);

            // Parse the first line into a message object. Retrieve the body as a string.
            //   This string was encoded as Base64 when it was written.
            var messageObject = JObject.Parse(fileLines[0]);
            var body = messageObject.Value<string>("Body");

            // Convert the body from Base64, then from UTF-32 to text, and write it out to the new file
            //   so you can view the result.
            string outputResult = System.Text.Encoding.UTF32.GetString(System.Convert.FromBase64String(body));

            System.IO.File.WriteAllText(outputFilePathAndName, outputResult);
        }
    }
}
